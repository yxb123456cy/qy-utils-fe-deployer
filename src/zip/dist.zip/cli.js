// src/cli.ts
import { Command } from "commander";

// src/commands/deploy.ts
import ora from "ora";
import { Client } from "ssh2";

// src/utils/compress.ts
import fs from "fs";
import path from "path";
import process2 from "process";
import archiver from "archiver";
async function compressDist(dir = "dist", out = "dist.zip") {
  const outPath = path.resolve(process2.cwd(), out);
  const output = fs.createWriteStream(outPath);
  const archive = archiver("zip", { zlib: { level: 9 } });
  return new Promise((resolve, reject) => {
    output.on("close", () => resolve(outPath));
    archive.on("error", reject);
    archive.pipe(output);
    archive.directory(path.resolve(process2.cwd(), dir), false);
    archive.finalize();
  });
}

// src/utils/config.ts
import fs2 from "fs";
import path2 from "path";
import process4 from "process";
import yaml from "js-yaml";

// src/utils/env.ts
import process3 from "process";
function resolveEnv(value) {
  if (!value)
    return value;
  const envVar = value.match(/^\$\{(.+?)\}$/);
  if (envVar) {
    return process3.env[envVar[1]];
  }
  return value;
}

// src/utils/config.ts
function tryPaths() {
  const cwd = process4.cwd();
  return [
    path2.join(cwd, "fe-deployer.yaml"),
    path2.join(cwd, "fe-deployer.yml"),
    path2.join(cwd, "deploy.config.yaml"),
    path2.join(cwd, "deploy.config.yml")
  ];
}
function loadConfigForEnv(env) {
  const file = tryPaths().find((p) => fs2.existsSync(p));
  if (!file)
    throw new Error("Config file not found: fe-deployer.yaml or deploy.config.yaml");
  const doc = yaml.load(fs2.readFileSync(file, "utf-8"));
  const envConf = doc.envs?.[env];
  if (!envConf)
    throw new Error(`Env "${env}" not found in config`);
  if (doc.storage) {
    const s = doc.storage;
    if (s.oss) {
      s.oss.accessKeyId = resolveEnv(s.oss.accessKeyId);
      s.oss.accessKeySecret = resolveEnv(s.oss.accessKeySecret);
    }
    if (s.minio) {
      s.minio.accessKey = resolveEnv(s.minio.accessKey);
      s.minio.secretKey = resolveEnv(s.minio.secretKey);
    }
    if (s.s3) {
      s.s3.accessKeyId = resolveEnv(s.s3.accessKeyId);
      s.s3.secretAccessKey = resolveEnv(s.s3.secretAccessKey);
    }
    if (s.cos) {
      s.cos.SecretId = resolveEnv(s.cos.SecretId);
      s.cos.SecretKey = resolveEnv(s.cos.SecretKey);
    }
  }
  return { env: envConf, storage: doc.storage, notify: doc.notify };
}

// src/utils/logger.ts
import chalk from "chalk";
var logInfo = (msg) => console.warn(chalk.blue(msg));
var logSuccess = (msg) => console.warn(chalk.green(msg));
var logError = (msg) => console.warn(chalk.red(msg));
logInfo("Mybatis");

// src/utils/notifier.ts
import axios from "axios";
async function postJSON(url, data) {
  await axios.post(url, data, { timeout: 1e4 });
}
async function notifyAll(channels = [], payload) {
  await Promise.allSettled(channels.map(async (ch) => {
    switch (ch.type) {
      case "dingtalk":
        await postJSON(ch.webhook, {
          msgtype: "markdown",
          markdown: { title: payload.title, text: `**${payload.title}**

${payload.text}` }
        });
        break;
      case "feishu":
        await postJSON(ch.webhook, {
          msg_type: "post",
          content: {
            post: {
              zh_cn: {
                title: payload.title,
                content: [[{ tag: "text", text: payload.text }]]
              }
            }
          }
        });
        break;
      case "slack":
        await postJSON(ch.webhook, {
          text: `*${payload.title}*
${payload.text}`
        });
        break;
      case "webhook":
      default:
        await postJSON(ch.webhook, payload);
    }
  }));
}

// src/utils/ssh.ts
import fs3 from "fs";
import os from "os";
import path3 from "path";
async function runRemoteCommands(conn, cmds = []) {
  for (const cmd of cmds) {
    await new Promise((resolve, reject) => {
      conn.exec(cmd, (err, stream) => {
        if (err)
          return reject(err);
        stream.on("close", (code) => {
          if (code !== 0)
            return reject(new Error(`Command failed: ${cmd}`));
          resolve();
        }).stderr.on("data", () => {
        });
      });
    });
  }
}
async function uploadAndUnzip(zipPath, remoteDir, conn) {
  const remoteZip = `${remoteDir.replace(/\/$/, "")}/dist.zip`;
  await new Promise((resolve, reject) => {
    conn.sftp((err, sftp) => {
      if (err)
        return reject(err);
      sftp.fastPut(zipPath, remoteZip, (err2) => {
        if (err2)
          return reject(err2);
        resolve();
      });
    });
  });
  await runRemoteCommands(conn, [
    `mkdir -p ${remoteDir}`,
    `cd ${remoteDir} && unzip -o dist.zip`
  ]);
}
function expandHome(p) {
  if (!p)
    return p;
  if (p.startsWith("~/"))
    return path3.join(os.homedir(), p.slice(2));
  return p;
}
function createConnectConfig(opts) {
  const conf = {
    host: opts.host,
    port: opts.port || 22,
    username: opts.username
  };
  if (opts.privateKey) {
    conf.privateKey = fs3.readFileSync(expandHome(opts.privateKey));
    if (opts.passphrase)
      conf.passphrase = opts.passphrase;
  } else if (opts.password) {
    conf.password = opts.password;
  }
  return conf;
}

// src/commands/deploy.ts
async function deploy(opts) {
  const spinner = ora(`Deploying to ${opts.env}...`).start();
  let success = false;
  try {
    const { env, notify } = loadConfigForEnv(opts.env);
    const zipPath = await compressDist();
    const conn = new Client();
    await new Promise((resolve, reject) => {
      conn.on("ready", () => resolve());
      conn.on("error", reject);
      conn.connect(createConnectConfig(env));
    });
    try {
      await runRemoteCommands(conn, env.preCommands || []);
      await uploadAndUnzip(zipPath, env.deployPath, conn);
      await runRemoteCommands(conn, env.postCommands || []);
      success = true;
      spinner.succeed("Deployment completed");
      logSuccess(`Deployed to ${env.host}:${env.deployPath}`);
    } finally {
      conn.end();
    }
    if (notify?.enable) {
      await notifyAll(notify.channels, {
        title: `Deploy ${opts.env} ${success ? "Success" : "Failed"}`,
        text: success ? `Host: ${env.host}
Path: ${env.deployPath}` : "See logs for details",
        success
      });
    }
  } catch (e) {
    spinner.fail("Deployment failed");
    logError(e?.message || String(e));
    throw e;
  }
}

// src/commands/docker.ts
import fs4 from "fs";
import path4 from "path";
import ejs from "ejs";
import inquirer from "inquirer";
async function docker() {
  const answers = await inquirer.prompt([
    { type: "input", name: "nodeVersion", message: "Node version:", default: "18" },
    { type: "confirm", name: "withNginx", message: "Include Nginx stage?", default: true }
  ]);
  const templateDir = path4.resolve(new URL(".", import.meta.url).pathname, "../../templates");
  const outputDir = process.cwd();
  for (const file of ["Dockerfile.ejs", "docker-compose.ejs"]) {
    const templatePath = path4.join(templateDir, file);
    const content = await ejs.renderFile(templatePath, answers);
    fs4.writeFileSync(path4.join(outputDir, file.replace(".ejs", "")), content);
  }
  const dockerignore = ["node_modules", "dist.zip", "dist/**/*.map", ".git", ".env", "coverage", "tmp", "logs"].join("\n");
  fs4.writeFileSync(path4.join(outputDir, ".dockerignore"), dockerignore);
  logSuccess("Docker templates generated successfully.");
}

// src/commands/upload.ts
import ora2 from "ora";

// src/utils/storage.ts
import fs5 from "fs";
import path5 from "path";
import process5 from "process";
import OSS from "ali-oss";
import COS from "cos-nodejs-sdk-v5";
import { Client as MinioClient } from "minio";
async function walkFiles(dir) {
  const base = path5.resolve(process5.cwd(), dir);
  const out = [];
  const stack = [base];
  while (stack.length) {
    const cur = stack.pop();
    for (const f of fs5.readdirSync(cur)) {
      const p = path5.join(cur, f);
      const stat = fs5.statSync(p);
      if (stat.isDirectory())
        stack.push(p);
      else out.push(p);
    }
  }
  return out;
}
async function uploadByStorage(cfg) {
  const files = await walkFiles(cfg.baseDir);
  const root = path5.resolve(process5.cwd(), cfg.baseDir);
  switch (cfg.provider) {
    case "oss": {
      const client = new OSS({
        region: cfg.oss.region,
        accessKeyId: cfg.oss.accessKeyId,
        accessKeySecret: cfg.oss.accessKeySecret,
        bucket: cfg.oss.bucket,
        endpoint: cfg.oss.endpoint
      });
      for (const file of files) {
        const key = path5.relative(root, file).replace(/\\/g, "/");
        await client.put(key, file);
      }
      break;
    }
    case "minio": {
      const m = new MinioClient({
        endPoint: cfg.minio.endPoint,
        port: cfg.minio.port ?? 9e3,
        useSSL: cfg.minio.useSSL ?? false,
        accessKey: cfg.minio.accessKey,
        secretKey: cfg.minio.secretKey
      });
      const bucket = cfg.minio.bucket;
      const exists = await m.bucketExists(bucket).catch(() => False);
      if (!exists)
        await m.makeBucket(bucket, "");
      for (const file of files) {
        const key = path5.relative(root, file).replace(/\\/g, "/");
        await m.fPutObject(bucket, key, file);
      }
      break;
    }
    case "s3": {
      const endPoint = cfg.s3.endpoint || "s3.amazonaws.com";
      const useSSL = true;
      const m = new MinioClient({
        endPoint,
        useSSL,
        accessKey: cfg.s3.accessKeyId,
        secretKey: cfg.s3.secretAccessKey,
        region: cfg.s3.region
      });
      const bucket = cfg.s3.bucket;
      const exists = await m.bucketExists(bucket).catch(() => False);
      if (!exists)
        await m.makeBucket(bucket, cfg.s3.region);
      for (const file of files) {
        const key = path5.relative(root, file).replace(/\\/g, "/");
        await m.fPutObject(bucket, key, file);
      }
      break;
    }
    case "cos": {
      const cos = new COS({
        SecretId: cfg.cos.SecretId,
        SecretKey: cfg.cos.SecretKey
      });
      const Bucket = cfg.cos.Bucket;
      const Region = cfg.cos.Region;
      for (const file of files) {
        const Key = path5.relative(root, file).replace(/\\/g, "/");
        await new Promise((resolve, reject) => {
          cos.putObject({
            Bucket,
            Region,
            Key,
            Body: fs5.createReadStream(file)
          }, (err) => err ? reject(err) : resolve());
        });
      }
      break;
    }
  }
}

// src/commands/upload.ts
async function upload(opts) {
  const envName = opts.env || "dev";
  const spinner = ora2(`Uploading artifacts for ${envName}...`).start();
  let ok = false;
  try {
    const { storage, notify } = loadConfigForEnv(envName);
    if (!storage)
      throw new Error("No storage config found");
    if (opts.target && opts.target !== storage.provider) {
      spinner.info(`Overriding provider: ${storage.provider} -> ${opts.target}`);
      storage.provider = opts.target;
    }
    await uploadByStorage(storage);
    ok = true;
    spinner.succeed("Upload completed");
    logSuccess(`Provider: ${storage.provider}`);
    if (notify?.enable) {
      await notifyAll(notify.channels, {
        title: `Upload ${envName} Success`,
        text: `Provider: ${storage.provider}
BaseDir: ${storage.baseDir}`,
        success: true
      });
    }
  } catch (e) {
    spinner.fail("Upload failed");
    try {
      const { notify } = loadConfigForEnv(envName);
      if (notify?.enable) {
        await notifyAll(notify.channels, {
          title: `Upload ${envName} Failed`,
          text: e?.message || String(e),
          success: false
        });
      }
    } catch (_) {
    }
    throw e;
  }
}

// src/cli.ts
var program = new Command();
program.name("fe-deployer").description("Frontend deployment toolset").version("1.0.0");
program.command("deploy").description("Deploy project to remote server via SSH & unzip").option("-e, --env <env>", "Environment (dev|test|prod)", "dev").action(deploy);
program.command("docker").description("Generate Dockerfile and docker-compose.yml").action(docker);
program.command("upload").description("Upload build artifacts to cloud storage (reads YAML storage config)").option("-t, --target <target>", "Override storage provider (oss|minio|s3|cos)").option("-e, --env <env>", "Environment to read storage config from", "dev").action(upload);
program.parse();
