"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/cli.ts
var import_commander = require("commander");

// src/commands/deploy.ts
var import_ora = __toESM(require("ora"), 1);
var import_ssh2 = require("ssh2");

// src/utils/compress.ts
var import_node_fs = __toESM(require("fs"), 1);
var import_node_path = __toESM(require("path"), 1);
var import_node_process = __toESM(require("process"), 1);
var import_archiver = __toESM(require("archiver"), 1);
async function compressDist(dir = "dist", out = "dist.zip") {
  const outPath = import_node_path.default.resolve(import_node_process.default.cwd(), out);
  const output = import_node_fs.default.createWriteStream(outPath);
  const archive = (0, import_archiver.default)("zip", { zlib: { level: 9 } });
  return new Promise((resolve, reject) => {
    output.on("close", () => resolve(outPath));
    archive.on("error", reject);
    archive.pipe(output);
    archive.directory(import_node_path.default.resolve(import_node_process.default.cwd(), dir), false);
    archive.finalize();
  });
}

// src/utils/config.ts
var import_node_fs2 = __toESM(require("fs"), 1);
var import_node_path2 = __toESM(require("path"), 1);
var import_node_process3 = __toESM(require("process"), 1);
var import_js_yaml = __toESM(require("js-yaml"), 1);

// src/utils/env.ts
var import_node_process2 = __toESM(require("process"), 1);
function resolveEnv(value) {
  if (!value)
    return value;
  const envVar = value.match(/^\$\{(.+?)\}$/);
  if (envVar) {
    return import_node_process2.default.env[envVar[1]];
  }
  return value;
}

// src/utils/config.ts
function tryPaths() {
  const cwd = import_node_process3.default.cwd();
  return [
    import_node_path2.default.join(cwd, "fe-deployer.yaml"),
    import_node_path2.default.join(cwd, "fe-deployer.yml"),
    import_node_path2.default.join(cwd, "deploy.config.yaml"),
    import_node_path2.default.join(cwd, "deploy.config.yml")
  ];
}
function loadConfigForEnv(env) {
  const file = tryPaths().find((p) => import_node_fs2.default.existsSync(p));
  if (!file)
    throw new Error("Config file not found: fe-deployer.yaml or deploy.config.yaml");
  const doc = import_js_yaml.default.load(import_node_fs2.default.readFileSync(file, "utf-8"));
  const envConf = doc.envs?.[env];
  if (!envConf)
    throw new Error(`Env "${env}" not found in config`);
  if (doc.storage) {
    const s = doc.storage;
    if (s.oss) {
      s.oss.accessKeyId = resolveEnv(s.oss.accessKeyId);
      s.oss.accessKeySecret = resolveEnv(s.oss.accessKeySecret);
    }
    if (s.minio) {
      s.minio.accessKey = resolveEnv(s.minio.accessKey);
      s.minio.secretKey = resolveEnv(s.minio.secretKey);
    }
    if (s.s3) {
      s.s3.accessKeyId = resolveEnv(s.s3.accessKeyId);
      s.s3.secretAccessKey = resolveEnv(s.s3.secretAccessKey);
    }
    if (s.cos) {
      s.cos.SecretId = resolveEnv(s.cos.SecretId);
      s.cos.SecretKey = resolveEnv(s.cos.SecretKey);
    }
  }
  return { env: envConf, storage: doc.storage, notify: doc.notify };
}

// src/utils/logger.ts
var import_chalk = __toESM(require("chalk"), 1);
var logInfo = (msg) => console.warn(import_chalk.default.blue(msg));
var logSuccess = (msg) => console.warn(import_chalk.default.green(msg));
var logError = (msg) => console.warn(import_chalk.default.red(msg));
logInfo("Mybatis");

// src/utils/notifier.ts
var import_axios = __toESM(require("axios"), 1);
async function postJSON(url, data) {
  await import_axios.default.post(url, data, { timeout: 1e4 });
}
async function notifyAll(channels = [], payload) {
  await Promise.allSettled(channels.map(async (ch) => {
    switch (ch.type) {
      case "dingtalk":
        await postJSON(ch.webhook, {
          msgtype: "markdown",
          markdown: { title: payload.title, text: `**${payload.title}**

${payload.text}` }
        });
        break;
      case "feishu":
        await postJSON(ch.webhook, {
          msg_type: "post",
          content: {
            post: {
              zh_cn: {
                title: payload.title,
                content: [[{ tag: "text", text: payload.text }]]
              }
            }
          }
        });
        break;
      case "slack":
        await postJSON(ch.webhook, {
          text: `*${payload.title}*
${payload.text}`
        });
        break;
      case "webhook":
      default:
        await postJSON(ch.webhook, payload);
    }
  }));
}

// src/utils/ssh.ts
var import_node_fs3 = __toESM(require("fs"), 1);
var import_node_os = __toESM(require("os"), 1);
var import_node_path3 = __toESM(require("path"), 1);
async function runRemoteCommands(conn, cmds = []) {
  for (const cmd of cmds) {
    await new Promise((resolve, reject) => {
      conn.exec(cmd, (err, stream) => {
        if (err)
          return reject(err);
        stream.on("close", (code) => {
          if (code !== 0)
            return reject(new Error(`Command failed: ${cmd}`));
          resolve();
        }).stderr.on("data", () => {
        });
      });
    });
  }
}
async function uploadAndUnzip(zipPath, remoteDir, conn) {
  const remoteZip = `${remoteDir.replace(/\/$/, "")}/dist.zip`;
  await new Promise((resolve, reject) => {
    conn.sftp((err, sftp) => {
      if (err)
        return reject(err);
      sftp.fastPut(zipPath, remoteZip, (err2) => {
        if (err2)
          return reject(err2);
        resolve();
      });
    });
  });
  await runRemoteCommands(conn, [
    `mkdir -p ${remoteDir}`,
    `cd ${remoteDir} && unzip -o dist.zip`
  ]);
}
function expandHome(p) {
  if (!p)
    return p;
  if (p.startsWith("~/"))
    return import_node_path3.default.join(import_node_os.default.homedir(), p.slice(2));
  return p;
}
function createConnectConfig(opts) {
  const conf = {
    host: opts.host,
    port: opts.port || 22,
    username: opts.username
  };
  if (opts.privateKey) {
    conf.privateKey = import_node_fs3.default.readFileSync(expandHome(opts.privateKey));
    if (opts.passphrase)
      conf.passphrase = opts.passphrase;
  } else if (opts.password) {
    conf.password = opts.password;
  }
  return conf;
}

// src/commands/deploy.ts
async function deploy(opts) {
  const spinner = (0, import_ora.default)(`Deploying to ${opts.env}...`).start();
  let success = false;
  try {
    const { env, notify } = loadConfigForEnv(opts.env);
    const zipPath = await compressDist();
    const conn = new import_ssh2.Client();
    await new Promise((resolve, reject) => {
      conn.on("ready", () => resolve());
      conn.on("error", reject);
      conn.connect(createConnectConfig(env));
    });
    try {
      await runRemoteCommands(conn, env.preCommands || []);
      await uploadAndUnzip(zipPath, env.deployPath, conn);
      await runRemoteCommands(conn, env.postCommands || []);
      success = true;
      spinner.succeed("Deployment completed");
      logSuccess(`Deployed to ${env.host}:${env.deployPath}`);
    } finally {
      conn.end();
    }
    if (notify?.enable) {
      await notifyAll(notify.channels, {
        title: `Deploy ${opts.env} ${success ? "Success" : "Failed"}`,
        text: success ? `Host: ${env.host}
Path: ${env.deployPath}` : "See logs for details",
        success
      });
    }
  } catch (e) {
    spinner.fail("Deployment failed");
    logError(e?.message || String(e));
    throw e;
  }
}

// src/commands/docker.ts
var import_node_fs4 = __toESM(require("fs"), 1);
var import_node_path4 = __toESM(require("path"), 1);
var import_ejs = __toESM(require("ejs"), 1);
var import_inquirer = __toESM(require("inquirer"), 1);
var import_meta = {};
async function docker() {
  const answers = await import_inquirer.default.prompt([
    { type: "input", name: "nodeVersion", message: "Node version:", default: "18" },
    { type: "confirm", name: "withNginx", message: "Include Nginx stage?", default: true }
  ]);
  const templateDir = import_node_path4.default.resolve(new URL(".", import_meta.url).pathname, "../../templates");
  const outputDir = process.cwd();
  for (const file of ["Dockerfile.ejs", "docker-compose.ejs"]) {
    const templatePath = import_node_path4.default.join(templateDir, file);
    const content = await import_ejs.default.renderFile(templatePath, answers);
    import_node_fs4.default.writeFileSync(import_node_path4.default.join(outputDir, file.replace(".ejs", "")), content);
  }
  const dockerignore = ["node_modules", "dist.zip", "dist/**/*.map", ".git", ".env", "coverage", "tmp", "logs"].join("\n");
  import_node_fs4.default.writeFileSync(import_node_path4.default.join(outputDir, ".dockerignore"), dockerignore);
  logSuccess("Docker templates generated successfully.");
}

// src/commands/upload.ts
var import_ora2 = __toESM(require("ora"), 1);

// src/utils/storage.ts
var import_node_fs5 = __toESM(require("fs"), 1);
var import_node_path5 = __toESM(require("path"), 1);
var import_node_process4 = __toESM(require("process"), 1);
var import_ali_oss = __toESM(require("ali-oss"), 1);
var import_cos_nodejs_sdk_v5 = __toESM(require("cos-nodejs-sdk-v5"), 1);
var import_minio = require("minio");
async function walkFiles(dir) {
  const base = import_node_path5.default.resolve(import_node_process4.default.cwd(), dir);
  const out = [];
  const stack = [base];
  while (stack.length) {
    const cur = stack.pop();
    for (const f of import_node_fs5.default.readdirSync(cur)) {
      const p = import_node_path5.default.join(cur, f);
      const stat = import_node_fs5.default.statSync(p);
      if (stat.isDirectory())
        stack.push(p);
      else out.push(p);
    }
  }
  return out;
}
async function uploadByStorage(cfg) {
  const files = await walkFiles(cfg.baseDir);
  const root = import_node_path5.default.resolve(import_node_process4.default.cwd(), cfg.baseDir);
  switch (cfg.provider) {
    case "oss": {
      const client = new import_ali_oss.default({
        region: cfg.oss.region,
        accessKeyId: cfg.oss.accessKeyId,
        accessKeySecret: cfg.oss.accessKeySecret,
        bucket: cfg.oss.bucket,
        endpoint: cfg.oss.endpoint
      });
      for (const file of files) {
        const key = import_node_path5.default.relative(root, file).replace(/\\/g, "/");
        await client.put(key, file);
      }
      break;
    }
    case "minio": {
      const m = new import_minio.Client({
        endPoint: cfg.minio.endPoint,
        port: cfg.minio.port ?? 9e3,
        useSSL: cfg.minio.useSSL ?? false,
        accessKey: cfg.minio.accessKey,
        secretKey: cfg.minio.secretKey
      });
      const bucket = cfg.minio.bucket;
      const exists = await m.bucketExists(bucket).catch(() => False);
      if (!exists)
        await m.makeBucket(bucket, "");
      for (const file of files) {
        const key = import_node_path5.default.relative(root, file).replace(/\\/g, "/");
        await m.fPutObject(bucket, key, file);
      }
      break;
    }
    case "s3": {
      const endPoint = cfg.s3.endpoint || "s3.amazonaws.com";
      const useSSL = true;
      const m = new import_minio.Client({
        endPoint,
        useSSL,
        accessKey: cfg.s3.accessKeyId,
        secretKey: cfg.s3.secretAccessKey,
        region: cfg.s3.region
      });
      const bucket = cfg.s3.bucket;
      const exists = await m.bucketExists(bucket).catch(() => False);
      if (!exists)
        await m.makeBucket(bucket, cfg.s3.region);
      for (const file of files) {
        const key = import_node_path5.default.relative(root, file).replace(/\\/g, "/");
        await m.fPutObject(bucket, key, file);
      }
      break;
    }
    case "cos": {
      const cos = new import_cos_nodejs_sdk_v5.default({
        SecretId: cfg.cos.SecretId,
        SecretKey: cfg.cos.SecretKey
      });
      const Bucket = cfg.cos.Bucket;
      const Region = cfg.cos.Region;
      for (const file of files) {
        const Key = import_node_path5.default.relative(root, file).replace(/\\/g, "/");
        await new Promise((resolve, reject) => {
          cos.putObject({
            Bucket,
            Region,
            Key,
            Body: import_node_fs5.default.createReadStream(file)
          }, (err) => err ? reject(err) : resolve());
        });
      }
      break;
    }
  }
}

// src/commands/upload.ts
async function upload(opts) {
  const envName = opts.env || "dev";
  const spinner = (0, import_ora2.default)(`Uploading artifacts for ${envName}...`).start();
  let ok = false;
  try {
    const { storage, notify } = loadConfigForEnv(envName);
    if (!storage)
      throw new Error("No storage config found");
    if (opts.target && opts.target !== storage.provider) {
      spinner.info(`Overriding provider: ${storage.provider} -> ${opts.target}`);
      storage.provider = opts.target;
    }
    await uploadByStorage(storage);
    ok = true;
    spinner.succeed("Upload completed");
    logSuccess(`Provider: ${storage.provider}`);
    if (notify?.enable) {
      await notifyAll(notify.channels, {
        title: `Upload ${envName} Success`,
        text: `Provider: ${storage.provider}
BaseDir: ${storage.baseDir}`,
        success: true
      });
    }
  } catch (e) {
    spinner.fail("Upload failed");
    try {
      const { notify } = loadConfigForEnv(envName);
      if (notify?.enable) {
        await notifyAll(notify.channels, {
          title: `Upload ${envName} Failed`,
          text: e?.message || String(e),
          success: false
        });
      }
    } catch (_) {
    }
    throw e;
  }
}

// src/cli.ts
var program = new import_commander.Command();
program.name("fe-deployer").description("Frontend deployment toolset").version("1.0.0");
program.command("deploy").description("Deploy project to remote server via SSH & unzip").option("-e, --env <env>", "Environment (dev|test|prod)", "dev").action(deploy);
program.command("docker").description("Generate Dockerfile and docker-compose.yml").action(docker);
program.command("upload").description("Upload build artifacts to cloud storage (reads YAML storage config)").option("-t, --target <target>", "Override storage provider (oss|minio|s3|cos)").option("-e, --env <env>", "Environment to read storage config from", "dev").action(upload);
program.parse();
